The templates in this folder will help you finish out the Get Requests module. Feel free to take these templates and build upon them. 
# Basic Get Template
This template is a basic form of a GET request to access information in the API and then output the information to the console.
# GET Request with Body
This template allows you to send information in the body of the API call. This is required at times when there are too many parameters to put into the endpoint.
# GET Request with Variable Storage
This template is a GET request that stores the output into a variable to access later.
