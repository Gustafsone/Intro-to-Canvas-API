The templates in this folder are for POST and PUT Requests.
