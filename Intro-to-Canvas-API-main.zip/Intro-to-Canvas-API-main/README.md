# Intro-to-Canvas-API
The GET Requests folder has some scripts to help you GET data out of the API.
The Non-GET Requests folder is for POST and PUT requests.
